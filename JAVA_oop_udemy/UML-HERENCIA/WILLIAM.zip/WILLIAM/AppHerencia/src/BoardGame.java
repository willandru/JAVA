
public class BoardGame extends Game{
	BoardGame(){
		System.out.println("Constructor BoardGame()");
	}
}

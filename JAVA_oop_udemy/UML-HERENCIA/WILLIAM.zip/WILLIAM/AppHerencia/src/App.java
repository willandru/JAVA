
public class App {

	public static void main(String[] args) {
		Item i= new Item();
		Game g= new Game();
		CD cd= new CD();
		DVD dvd= new DVD();
		VideoGame vg= new VideoGame();
		BoardGame bg= new BoardGame();

	}

}
